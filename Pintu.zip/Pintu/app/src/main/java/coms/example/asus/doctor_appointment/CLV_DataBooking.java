package coms.example.asus.doctor_appointment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class CLV_DataBooking extends ArrayAdapter<String> {
    //Declarasi variable
    private final Activity context;
    private ArrayList<String> vNama_lengkap;
    private ArrayList<String> vNim;
    private ArrayList<String> vTanggal;
    private ArrayList<String> vWaktu;
    private ArrayList<String> vStatus;

    public CLV_DataBooking(Activity context, ArrayList<String>Nama_lengkap, ArrayList<String> Nim, ArrayList<String> Tanggal, ArrayList<String> Waktu, ArrayList<String> Status) {
        super(context, R.layout.item_history, Nama_lengkap);
        this.context            = context;
        this.vNama_lengkap       = Nama_lengkap;
        this.vNim        = Nim;
        this.vTanggal            = Tanggal;
        this.vWaktu            = Waktu;
        this.vStatus    = Status;

    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView = inflater.inflate(R.layout.item_history, null, true);

        //Declarasi komponen
        TextView nama_lengkap = rowView.findViewById(R.id.namaBooking);
        TextView nim = rowView.findViewById(R.id.nim);
        TextView tanggal = rowView.findViewById(R.id.tanggal);
        TextView waktu = rowView.findViewById(R.id.waktu);
        TextView status = rowView.findViewById(R.id.status);

        //Set Parameter Value sesuai widget textview
        nama_lengkap.setText(vNama_lengkap.get(position));
        nim.setText(vNim.get(position));
        tanggal.setText(vTanggal.get(position));
        waktu.setText(vWaktu.get(position));
        status.setText(vStatus.get(position));

        //Load the animation from the xml file and set it to the row
        //load animasi untuk listview
        Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.down_from_top);
        animation.setDuration(500);
        rowView.startAnimation(animation);

        return rowView;
    }
}



