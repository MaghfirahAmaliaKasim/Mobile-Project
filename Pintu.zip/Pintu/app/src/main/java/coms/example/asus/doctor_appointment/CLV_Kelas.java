package coms.example.asus.doctor_appointment;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import coms.example.asus.doctor_appointment.R;
import de.hdodenhof.circleimageview.CircleImageView;

public class CLV_Kelas extends ArrayAdapter<String> {

    private final Activity context;
    private ArrayList<String> vNamakelas;
    private ArrayList<String> vLokasi;
    private ArrayList<String> vLantai;
    private ArrayList<String> vPhoto;


    public CLV_Kelas(Activity context, ArrayList<String> Namakelas, ArrayList<String> Lokasi, ArrayList<String> Lantai, ArrayList<String> Photo) {
        super(context, R.layout.item_treatment,Namakelas);
        this.context          = context;
        this.vNamakelas = Namakelas;
        this.vLokasi      = Lokasi;
        this.vLantai           = Lantai;
        this.vPhoto           = Photo;
    }

    @SuppressLint("MissingInflatedId")
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView= inflater.inflate(R.layout.item_kelas, null, true);

        //Declarasi komponen
        TextView namakelas  = rowView.findViewById(R.id.TVjenis);
        TextView lokasi         = rowView.findViewById(R.id.iddeskripsi);
        TextView lantai            = rowView.findViewById(R.id.idbiaya);
        CircleImageView photo      = rowView.findViewById(R.id.treatmentlist);

        //Set Parameter Value sesuai widget textview
        namakelas.setText(vNamakelas.get(position));
        lokasi.setText(vLokasi.get(position));
        lantai.setText(vLantai.get(position));

        if (vPhoto.get(position).equals(""))
        {
            Picasso.get().load("https://tekajeapunya.com/kelompok_6/image/noimage.png").into(photo);
        }
        else
        {
            Picasso.get().load("https://tekajeapunya.com/kelompok_6/image/"+vPhoto.get(position)).into(photo);
        }


        //Load the animation from the xml file and set it to the row
        //load animasi untuk listview
        Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.down_from_top);
        animation.setDuration(500);
        rowView.startAnimation(animation);

        return rowView;
    }



}