package coms.example.asus.doctor_appointment;

public class DbContact {
    public static final String SERVER_LOGIN_URL = "https://tekajeapunya.com/kelompok_6/Dotudoor/login_user.php";
    public static final String SERVER_REGISTER_URL = "https://tekajeapunya.com/kelompok_6/Dotudoor/register_user.php";
    public static final String SERVER_LOGINADMIN_URL="https://tekajeapunya.com/kelompok_6/Dotudoor/login_admin.php";
}
