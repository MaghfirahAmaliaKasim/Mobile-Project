package coms.example.asus.doctor_appointment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Klinik extends AppCompatActivity {

    ImageView ic_kembali;
    TextView namaRuangan, namaRuangan2;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_klinik_user);

        //set variable sesuai dengan widget yang digunakan

        ic_kembali = findViewById(R.id.ic_kembaliuser);
        namaRuangan = findViewById(R.id.TVnama_klinik);
        namaRuangan2 = findViewById(R.id.TVnama_klinik2);

        ic_kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Klinik.this, AdminHome.class);
                startActivity(intent);
            }
        });
        namaRuangan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Klinik.this, Laboratorium.class);
                startActivity(intent);
            }
        });
        namaRuangan2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Klinik.this, Admin_Kelas.class);
                startActivity(intent);
            }
        });


    }


}