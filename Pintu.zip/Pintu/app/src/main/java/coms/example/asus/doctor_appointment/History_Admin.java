package coms.example.asus.doctor_appointment;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class History_Admin extends AppCompatActivity {

    SwipeRefreshLayout srl_main;
    ArrayList<String> array_nama_lengkap, array_nim, array_tanggal, array_waktu, array_status;
    ProgressDialog progressDialog;
    ListView listProses;
    ImageView ic_kembali;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history_admin);

        ///set variable sesuai dengan widget yang digunakan
        listProses = findViewById(R.id.LV);
        srl_main = findViewById(R.id.swipe_container);
        progressDialog = new ProgressDialog(this);

        ic_kembali = findViewById(R.id.ic_back);

        ic_kembali.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(History_Admin.this, AdminHome.class);
                startActivity(intent);
            }
        });
        srl_main.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                srollRefresh();
                srl_main.setRefreshing(false);
            }
        });
        // Scheme colors for animation
        srl_main.setColorSchemeColors(
                getResources().getColor(android.R.color.holo_blue_bright),
                getResources().getColor(android.R.color.holo_green_light),
                getResources().getColor(android.R.color.holo_orange_light),
                getResources().getColor(android.R.color.holo_red_light)

        );

        srollRefresh();

    }

    public void srollRefresh() {
        progressDialog.setMessage("Mengambil Data....");
        progressDialog.setCancelable(false);
        progressDialog.show();
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {getData(); }
        }, 2000);
    }


    void initializerArray() {
        array_nama_lengkap   = new ArrayList<String>();
        array_nim      = new ArrayList<String>();
        array_tanggal        = new ArrayList<String>();
        array_waktu        = new ArrayList<String>();
        array_status   = new ArrayList<String>();

        // clear ini untuk menginilisasi array
        array_nama_lengkap.clear();
        array_nim.clear();
        array_tanggal.clear();
        array_waktu.clear();
        array_status.clear();

    }

    public void getData() {
        initializerArray();
        AndroidNetworking.get("https://tekajeapunya.com/kelompok_6/getBooking.php")
                .setTag("Get Data")
                .setPriority(Priority.MEDIUM)
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progressDialog.dismiss();

                        try {

                            Boolean status = response.getBoolean("status");
                            if (status) {
                                JSONArray ja = response.getJSONArray("result");
                                Log.d("respon", "" + ja);
                                for (int i = 0 ; i < ja.length(); i++) {
                                    JSONObject jo = ja.getJSONObject(i);


                                    array_nama_lengkap.add(jo.getString("nama_lengkap"));
                                    array_nim.add(jo.getString("nim"));
                                    array_tanggal.add(jo.getString("tanggal"));
                                    array_waktu.add(jo.getString("waktu"));
                                    array_status.add(jo.getString("status"));

                                }

                                final CLV_DataBooking adapter = new CLV_DataBooking(History_Admin.this, array_nama_lengkap, array_nim, array_tanggal, array_waktu, array_status);
                                //Set adapter to list
                                listProses.setAdapter(adapter);

                                //edit and delete
                                listProses.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        Log.d("TestKlik", "" + array_nama_lengkap.get(position));
                                        Toast.makeText(History_Admin.this, array_nama_lengkap.get(position), Toast.LENGTH_SHORT).show();

                                        Intent i = new Intent(History_Admin.this,Update_History.class);
                                        i.putExtra("nama_lengkap", array_nama_lengkap.get(position));
                                        i.putExtra("nim", array_nim.get(position));
                                        i.putExtra("tanggal", array_tanggal.get(position));
                                        i.putExtra("waktu", array_waktu.get(position));
                                        i.putExtra("status", array_status.get(position));
                                        startActivity(i);

                                    }
                                });


                            } else {
                                Toast.makeText(History_Admin.this, "Gagal Mengambil Data", Toast.LENGTH_SHORT).show();

                            }
                        }

                        catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {

                    }
                });

    }


}

