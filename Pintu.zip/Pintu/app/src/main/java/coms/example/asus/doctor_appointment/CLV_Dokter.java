package coms.example.asus.doctor_appointment;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;

public class CLV_Dokter extends ArrayAdapter<String> {
    //Declarasi variable
    private final Activity context;
    private ArrayList<String> vNama_dosen;
    private ArrayList<String> vProdi;
    private ArrayList<String> vKontak;
    private ArrayList<String> vJadwal;
    private ArrayList<String> vRuangan;
    private  ArrayList<String> vPhoto;

    public CLV_Dokter(Activity context, ArrayList<String> Nama_dokter, ArrayList<String> Keahlian, ArrayList<String> Kontak, ArrayList<String> Jadwal, ArrayList<String> Alamat_klinik, ArrayList<String> Photo) {
        super(context, R.layout.item_dokter, Nama_dokter);
        this.context            = context;
        this.vNama_dosen       = Nama_dokter;
        this.vProdi        = Keahlian;
        this.vKontak            = Kontak;
        this.vJadwal            = Jadwal;
        this.vRuangan    = Alamat_klinik;
        this.vPhoto             = Photo;

    }


    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        //Load Custom Layout untuk list
        View rowView = inflater.inflate(R.layout.item_dokter, null, true);

        //Declarasi komponen
        TextView nama_dosen = rowView.findViewById(R.id.Tvnamadok);
        TextView prodi = rowView.findViewById(R.id.TVkeahlian);
        TextView kontak = rowView.findViewById(R.id.Tvkontak);
        TextView jadwal = rowView.findViewById(R.id.TVjadwal);
        TextView ruangan = rowView.findViewById(R.id.TVnama_klinik);
        CircleImageView photo = rowView.findViewById(R.id.profil);

        //Set Parameter Value sesuai widget textview
        nama_dosen.setText(vNama_dosen.get(position));
        prodi.setText(vProdi.get(position));
        kontak.setText(vKontak.get(position));
        jadwal.setText(vJadwal.get(position));
        ruangan.setText(vRuangan.get(position));

        if (vPhoto.get(position).equals(""))
        {
            Picasso.get().load("https://tekajeapunya.com/kelompok_6/image/noimage.png").into(photo);
        }
        else
        {
            Picasso.get().load("https://tekajeapunya.com/kelompok_6/image/"+vPhoto.get(position)).into(photo);
        }

        //Load the animation from the xml file and set it to the row
        //load animasi untuk listview
        Animation animation = AnimationUtils.loadAnimation(getContext(), R.anim.down_from_top);
        animation.setDuration(500);
        rowView.startAnimation(animation);

        return rowView;
    }
}



