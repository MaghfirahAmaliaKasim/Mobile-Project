package coms.example.asus.doctor_appointment;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import org.json.JSONException;
import org.json.JSONObject;

public class Update_History extends AppCompatActivity {

    EditText ETnama_lengkap, ETNim, ETanggal, ETWaktu, ETStatus;
    String nama_lengkap, nim, tanggal, waktu, status;
    ProgressDialog progressDialog;
    Button BTNUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_history);

        androidx.appcompat.widget.Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar1);
        setSupportActionBar(toolbar);

        toolbar.setNavigationIcon(R.drawable.ic_kembali);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });


        ETnama_lengkap         = findViewById(R.id.etnama);
        ETNim          = findViewById(R.id.edJenis);
        ETanggal            = findViewById(R.id.edttanggal);
        ETWaktu            = findViewById(R.id.edtwaktu);
        ETStatus           = findViewById(R.id.edtstatus);
        BTNUpdate = findViewById(R.id.Reservasi);

        getDataIntent();

        progressDialog = new ProgressDialog(this);
        BTNUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nama_lengkap = ETnama_lengkap.getText().toString();
                new AlertDialog.Builder(Update_History.this)
                        .setTitle("Peringatan")
                        .setMessage("Apakah kamu ingin mengubah data" + nama_lengkap + "ini?")
                        .setCancelable(false)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                progressDialog.setTitle("please Waiting ...");
                                progressDialog.setMessage("Mengubah Data...");
                                progressDialog.setCancelable(false);
                                progressDialog.show();

                                nama_lengkap = ETnama_lengkap.getText().toString();
                                nim = ETNim.getText().toString();
                                tanggal = ETanggal.getText().toString();
                                waktu = ETWaktu.getText().toString();
                                status = ETStatus.getText().toString();

                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        validatingData();
                                    }
                                },1000);
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        }).show();

            }
        });

    }
    void getDataIntent() {
        Bundle bundle = getIntent().getExtras();
        if(bundle!=null){
            ETnama_lengkap.setText(bundle.getString("nama_lengkap"));
            ETNim.setText(bundle.getString("nim"));
            ETanggal.setText(bundle.getString("tanggal"));
            ETWaktu.setText(bundle.getString("waktu"));
            ETStatus.setText(bundle.getString("status"));
        }else{
            ETnama_lengkap.setText("");
            ETNim.setText("");
            ETanggal.setText("");
            ETWaktu.setText("");
            ETStatus.setText("");
        }
    }

    void validatingData(){
        if(nama_lengkap.equals("") || nim.equals("") || tanggal.equals("") || waktu.equals("") || status.equals("") ){
            progressDialog.dismiss();
            Toast.makeText(Update_History.this, "Data tidak boleh kosong", Toast.LENGTH_SHORT).show();
        } else {
            updateData();
        }

    }

    void updateData() {
        AndroidNetworking.post("https://tekajeapunya.com/kelompok_6/updateBooking.php")
                .addBodyParameter("nama_lengkap", "" + nama_lengkap)
                .addBodyParameter("nim", "" + nim)
                .addBodyParameter("tanggal", "" + tanggal)
                .addBodyParameter("waktu", "" + waktu)
                .addBodyParameter("status", "" + status)
                .setPriority(Priority.MEDIUM)
                .setTag("Update Data")
                .build()
                .getAsJSONObject(new JSONObjectRequestListener() {
                    @Override
                    public void onResponse(JSONObject response) {
                        progressDialog.dismiss();
                        Log.d("cekUpdate", "" + response);
                        try {
                            Boolean status = response.getBoolean("status");
                            String pesan = response.getString("result");
                            Toast.makeText(Update_History.this, "" + pesan, Toast.LENGTH_SHORT).show();
                            Log.d("status", "" + status);

                            if (status) {
                                new AlertDialog.Builder(Update_History.this)
                                        .setMessage("Data berhasil di update!")
                                        .setCancelable(false)
                                        .setPositiveButton("Kembali", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent i = new Intent(Update_History.this, History_Admin.class);
                                                startActivity(i);
                                                Update_History.this.finish();
                                            }
                                        })
                                        .show();


                            } else {
                                new AlertDialog.Builder(Update_History.this)
                                        .setMessage("Gagal mengupdate data !")
                                        .setPositiveButton("Kembali", new DialogInterface.OnClickListener() {
                                            @Override
                                            public void onClick(DialogInterface dialog, int which) {
                                                Intent i = getIntent();
                                                setResult(RESULT_CANCELED, i);
                                                Update_History.this.finish();
                                            }
                                        })
                                        .setCancelable(false)
                                        .show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onError(ANError anError) {
                        Log.d("Cannot Update Your data", "" + anError.getErrorBody());
                    }
                });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.delete,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        nama_lengkap = ETnama_lengkap.getText().toString();
        int id = item.getItemId();
        if(id==R.id.action_delete){
            new AlertDialog.Builder(Update_History.this)
                    .setMessage("Apakah kamu ingin menghapus data dosen "+nama_lengkap+"?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            progressDialog.setMessage("Menghapus...");
                            progressDialog.setCancelable(false);
                            progressDialog.show();

                            AndroidNetworking.post("https://tekajeapunya.com/kelompok_6/hapusDosen.php")
                                    .addBodyParameter("nama_lengkap",""+nama_lengkap)
                                    .setPriority(Priority.MEDIUM)
                                    .build()
                                    .getAsJSONObject(new JSONObjectRequestListener() {
                                        @Override
                                        public void onResponse(JSONObject response) {
                                            progressDialog.dismiss();
                                            try {
                                                Boolean status = response.getBoolean("status");
                                                Log.d("status",""+status);
                                                String result = response.getString("result");
                                                if(status){
                                                    new AlertDialog.Builder(Update_History.this)
                                                            .setMessage("Data telah dihapus!")
                                                            .setCancelable(false)
                                                            .setPositiveButton("Kembali", new DialogInterface.OnClickListener() {
                                                                @Override
                                                                public void onClick(DialogInterface dialog, int which) {
                                                                    Intent i = new Intent(Update_History.this, History_Admin.class);
                                                                    startActivity(i);
                                                                    Update_History.this.finish();
                                                                }
                                                            })
                                                            .show();

                                                }else{
                                                    Toast.makeText(Update_History.this, ""+result, Toast.LENGTH_SHORT).show();
                                                }
                                            }catch (Exception e){
                                                e.printStackTrace();
                                            }
                                        }

                                        @Override
                                        public void onError(ANError anError) {
                                            anError.printStackTrace();
                                        }
                                    });
                        }
                    })
                    .setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.cancel();
                        }
                    })
                    .show();


        }
        return super.onOptionsItemSelected(item);
    }

}
