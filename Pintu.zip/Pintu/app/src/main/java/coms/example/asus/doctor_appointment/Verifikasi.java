package coms.example.asus.doctor_appointment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Verifikasi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verifikasi);
    }
}